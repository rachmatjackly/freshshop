<?php
    session_start();
    if(!isset($_SESSION['login'])){
        header('location:../login.php');
    }
    $id = $_SESSION['id'];
    $koneksi = mysqli_connect('localhost','root','','freshshop');
    $hasil = mysqli_query($koneksi, "SELECT * FROM users WHERE id = $id");
    ob_start();
    include('header.php');
?>

<?php
    include('Template/_post.php');
?>

<?php
    include('footer.php');
?>ss