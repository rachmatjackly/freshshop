<?php

require 'functions.php';

    if(isset($_POST["submit"])){
        if(tambah_produk($_POST)>0){
            echo "<script>
                    alert('Produk baru telah ditambahkan');
                    </script>";
        }else{
            echo mysqli_error($conn);
        }
    }
?>

<div class="container-fluid">
    <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Tambah Produk</h1>

          <div class="card mt-3">
	  <div class="card-header bg-success text-white">
      Form Tambah Produk
	  </div>
	  <div class="card-body">
	    <form method="post" action="" enctype="multipart/form-data">
		    <div class="form-group">
				<label>Nama Item</label>
	    		 <input type="nama" name="nama"  class="form-control" placeholder="Input Nama anda disini!" required>
			</div>
			<div class="form-group">
	    		<label>Harga</label>
	    		<input type="text" name="harga" class="form-control" placeholder="Input Nama anda disini!" required>
			</div>
			<div class="form-group">
	    		<label>Gambar</label>

                <input type="file" name="gambar" class="form-control" placeholder="Input Nama anda disini!" required>
			</div>
			<div class="form-group">
                <label>Description</label>
                <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
	    		<!-- <input type="texta" name="username" value="<?=$dump["username"]?>" class="form-control" placeholder="Input Nama anda disini!" required> -->
			</div>
                <button type="submit" class="btn btn-success" name="submit">Simpan</button>
	    	<button type="reset" class="btn btn-danger" name="breset">Kosongkan</button>

		</form>
	  </div>
	</div>