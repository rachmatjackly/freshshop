<!-- Header -->
<?php
  session_start();
  if(!isset($_SESSION['login'])){
      header('location:../login.php');
  }
  ob_start();
  include('header.php');
?>

<!--Main-->
<?php
  include('Template/_main.php');
  ?>

  <!-- Footer -->
  <?php
    include('footer.php');
    ?>
