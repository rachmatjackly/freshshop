<?php
$conn = mysqli_connect("localhost","root","","freshshop");

function registrasi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $nama = $data["nama"];
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    //cek username
    $result = mysqli_query($conn, "SELECT username FROM users WHERE username = '$username'");

    if(mysqli_fetch_assoc($result)){
        echo "<script>
                alert('Username sudah terdafatar');
            </script>";
        return false;  
    }

    if($password !== $password2) {
        echo "<script>
                alert('Konfirmasi Password tidak sesuai');
            </script>";
        return false; 
    }

    $password = password_hash($password, PASSWORD_DEFAULT);
    
    //memasukkan data ke db
    mysqli_query($conn, "INSERT INTO users VALUES('','$nama','$username','$password')");

    return mysqli_affected_rows($conn);
}

function tambah_produk($data){
    global $conn;

    $nama_produk = $data["nama"];
    $harga =  $data["harga"];
    $description =  $data["description"];
    // $gambar =  $data["gambar"];
    $ekstensi_diperbolehkan	= array('png','jpg');
    $nama = $_FILES['gambar']['name'];
    $x = explode('.', $nama);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['gambar']['size'];
			$file_tmp = $_FILES['gambar']['tmp_name'];
    
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
        if($ukuran < 1044070){
            move_uploaded_file($file_tmp, '../' . 'images/'.$nama);	
    mysqli_query($conn, "INSERT INTO product VALUES('','$nama_produk','$harga','$nama','$description','')");
    return mysqli_affected_rows($conn);
        }
    }
}
?>
