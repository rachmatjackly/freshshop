<!-- Shopping cart section  -->
<div class="cart-box-main">
        <div class="container">
            <div class="row">
            <h5 class="font-baloo font-size-20">Shopping Cart</h5>
                <div class="col-lg-12">
                    
                            <div class="row border-top py-3 mt-3">
                                <div class="col-sm-12 text-center py-2">
                                <img src="./images/empty_cart.png" alt="Empty Cart" class="img-fluid" style="height: 200px;">
                                <p class="font-baloo font-size-16 text-black-50">Empty Cart</p>
                            </div>
                            
                    </div>
                </div>
            </div>
                        <div class="row my-5">
                            <div class="col-lg-8 col-sm-12"></div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="order-box">
                        <h3>Order summary</h3>
                        <div class="d-flex">
                            <h4>Sub Total</h4>
                            <div class="ml-auto font-weight-bold"> <?php echo isset($subTotal) ? count($subTotal) : 0; ?> item&nbsp; </div>
                        </div>
                        <div class="d-flex gr-total">
                            <h5>Grand Total</h5>
                            <div class="ml-auto h5" id="deal-price"> <?php echo isset($subTotal) ? $Cart->getSum($subTotal) : 0; ?> </div>
                        </div>
                        <hr> </div>
                </div>
                <div class="col-12 d-flex shopping-box"><a href="checkout.html" class="ml-auto btn hvr-hover">Checkout</a> </div>
            </div>

        </div>
    </div>



<!-- !Shopping cart section  -->