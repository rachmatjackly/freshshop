<?php
    session_start();

    ob_start();
    include ('header.php');
?>

<?php
    include ('Template/_banner-area.php');

    // include ('Template/_category.php');

    include ('Template/_banner-ads.php');

    include ('Template/_top-best.php');

    include ('Template/_instagram.php');
?>

<?php
// include footer.php file
include ('footer.php');
?>